
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/naver-search.js
var naver_search_default = async (req) => {
  const url = new URL(req.url);
  const query = url.searchParams.get("query") || "";
  const display = url.searchParams.get("display") || "20";
  const res = await fetch(
    `https://openapi.naver.com/v1/search/book.json?query=${encodeURIComponent(query)}&display=${display}`,
    {
      headers: {
        "X-Naver-Client-Id": "lLKzrmO5gcIG4A_hZTLW",
        "X-Naver-Client-Secret": "V5GJqoTD91"
      }
    }
  );
  const data = await res.json();
  return new Response(JSON.stringify(data), {
    status: res.status,
    headers: { "Content-Type": "application/json" }
  });
};
var config = { path: "/api/naver/v1/search/book.json" };
export {
  config,
  naver_search_default as default
};
